'use strict';

require('dotenv').config();

const REQUIRED = ['DATABASE_URL', 'JWT_SECRET', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'];
const missing = REQUIRED.filter((key) => !process.env[key]);

if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(', ')}`);
  console.error('Copy .env.example to .env and fill in the values.');
  process.exit(1);
}

const env = process.env;

module.exports = {
  port: Number(env.PORT) || 3000,
  // Comma-separated list of allowed frontend origins, or * to allow any (handy for phone testing).
  corsOrigins: (env.CORS_ORIGIN || 'http://localhost:4200')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
  databaseUrl: env.DATABASE_URL,
  jwtSecret: env.JWT_SECRET,
  admin: { email: env.ADMIN_EMAIL, password: env.ADMIN_PASSWORD },
  smtp: {
    host: env.SMTP_HOST,
    port: Number(env.SMTP_PORT) || 587,
    user: env.SMTP_USER,
    pass: env.SMTP_PASS,
    from: env.MAIL_FROM || env.SMTP_USER,
  },
  reminders: {
    firstSendHour: 9, // first email of the day goes out at 09:00
    windowHours: 12, // N emails are spread across 09:00 -> 21:00
    maxPerDay: 12,
    recipientsPerEmail: 50, // BCC batch size, keeps SMTP providers happy
  },
};
