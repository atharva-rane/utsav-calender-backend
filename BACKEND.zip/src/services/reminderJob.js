'use strict';

const cron = require('node-cron');
const config = require('../config');
const { query } = require('../db');

const { firstSendHour, windowHours } = config.reminders;

/**
 * A reminder with N sends per day spreads them between 09:00 and 21:00.
 * Send number `sentCount` (0-based) becomes due at this hour.
 *   N=1 -> 09:00        N=3 -> 09:00, 13:00, 17:00        N=12 -> every hour from 09:00
 */
const hourWhenDue = ({ sent_count: sentCount, times_per_day: timesPerDay }) =>
  firstSendHour + sentCount * Math.max(1, Math.floor(windowHours / timesPerDay));

async function sendDueReminders(mailer) {
  const now = new Date();
  const today = now.toLocaleDateString('en-CA'); // YYYY-MM-DD in the server's timezone

  const pending = await query(
    `SELECT r.id, r.sent_count, r.times_per_day,
            e.title, e.date, to_char(e.time, 'HH24:MI') AS time, e.location, e.description
     FROM reminders r
     JOIN events e ON e.id = r.event_id
     WHERE r.remind_date = $1 AND r.sent_count < r.times_per_day`,
    [today],
  );

  const due = pending.filter((reminder) => now.getHours() >= hourWhenDue(reminder));
  if (!due.length) return;

  const emails = (await query('SELECT email FROM recipients')).map((row) => row.email);
  if (!emails.length) return; // keep the reminder pending until someone is subscribed

  for (const reminder of due) {
    try {
      await mailer.sendReminder(reminder, emails);
      // Only count a send after the email really went out, so failures are retried next minute.
      await query('UPDATE reminders SET sent_count = sent_count + 1 WHERE id = $1', [reminder.id]);
    } catch (err) {
      console.error(`[reminders] could not send "${reminder.title}":`, err.message);
    }
  }
}

/** Check every minute. Missed slots (e.g. server was down) are sent one per minute afterwards. */
function startReminderJob(mailer) {
  let running = false; // never let two runs overlap

  cron.schedule('* * * * *', async () => {
    if (running) return;
    running = true;
    try {
      await sendDueReminders(mailer);
    } catch (err) {
      console.error('[reminders] job failed:', err.message);
    } finally {
      running = false;
    }
  });
}

module.exports = { startReminderJob, hourWhenDue };
