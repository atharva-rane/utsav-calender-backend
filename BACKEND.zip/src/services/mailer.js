'use strict';

const nodemailer = require('nodemailer');
const config = require('../config');

const escapeHtml = (value) =>
  String(value ?? '').replace(
    /[&<>"']/g,
    (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char],
  );

const chunk = (items, size) =>
  Array.from({ length: Math.ceil(items.length / size) }, (_, i) =>
    items.slice(i * size, i * size + size),
  );

function renderReminderHtml(event) {
  const when = event.time ? `${event.date} at ${event.time}` : event.date;
  return `
    <div style="font-family:sans-serif;max-width:480px">
      <h2>${escapeHtml(event.title)}</h2>
      <p><b>${escapeHtml(when)}</b></p>
      ${event.location ? `<p>📍 ${escapeHtml(event.location)}</p>` : ''}
      ${event.description ? `<p>${escapeHtml(event.description)}</p>` : ''}
      <small>Sent by Utsav Calendar</small>
    </div>`;
}

/**
 * Create the email sender, or return null when SMTP is not configured.
 * `sendReminder(event, emails)` BCCs recipients in batches so nobody sees each other's address.
 */
function createMailer(smtp) {
  if (!smtp.host || !smtp.user || !smtp.pass) return null;

  const transport = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.port === 465, // 465 = implicit TLS, 587 = STARTTLS
    auth: { user: smtp.user, pass: smtp.pass },
  });

  return {
    async sendReminder(event, emails) {
      const html = renderReminderHtml(event);
      for (const batch of chunk(emails, config.reminders.recipientsPerEmail)) {
        await transport.sendMail({
          from: smtp.from,
          bcc: batch,
          subject: `Reminder: ${event.title}`,
          html,
        });
      }
    },
  };
}

module.exports = { createMailer, escapeHtml };
