'use strict';

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { HttpError } = require('../utils/errors');

const TOKEN_LIFETIME = { admin: '8h', user: '30d' };

/** Issue a JWT for the given role ('admin' | 'user'). */
const signToken = (role) =>
  jwt.sign({ role }, config.jwtSecret, { expiresIn: TOKEN_LIFETIME[role] });

/**
 * Require a valid "Authorization: Bearer <jwt>" header.
 * Pass roles to restrict access, e.g. requireAuth('admin').
 */
const requireAuth =
  (...allowedRoles) =>
  (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';

    try {
      req.user = jwt.verify(token, config.jwtSecret);
    } catch {
      return next(new HttpError(401, 'Please sign in again'));
    }

    if (allowedRoles.length && !allowedRoles.includes(req.user.role)) {
      return next(new HttpError(403, 'Admin access required'));
    }
    next();
  };

/** Constant-time string comparison (hashes first so lengths always match). */
const safeEqual = (a, b) => {
  const hash = (value) => crypto.createHash('sha256').update(String(value)).digest();
  return crypto.timingSafeEqual(hash(a), hash(b));
};

module.exports = { signToken, requireAuth, safeEqual };
