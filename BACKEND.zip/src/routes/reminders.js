'use strict';

const { Router } = require('express');
const config = require('../config');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { HttpError, asyncHandler } = require('../utils/errors');
const { isIsoDate, parseId } = require('../utils/validation');

const router = Router();
router.use(requireAuth());

const COLUMNS = 'id, event_id, remind_date, times_per_day, sent_count';

router.get(
  '/',
  asyncHandler(async (req, res) => {
    res.json(await query(`SELECT ${COLUMNS} FROM reminders ORDER BY remind_date, id`));
  }),
);

// POST /api/reminders  { event_id, remind_date: "YYYY-MM-DD", times_per_day: 1-12 }
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const eventId = parseId(req.body.event_id);
    const { remind_date: remindDate } = req.body;
    if (!isIsoDate(remindDate)) throw new HttpError(400, 'remind_date must be YYYY-MM-DD');

    const timesPerDay = Math.min(
      Math.max(Number.parseInt(req.body.times_per_day, 10) || 1, 1),
      config.reminders.maxPerDay,
    );

    // INSERT ... SELECT only inserts when the event exists.
    const [created] = await query(
      `INSERT INTO reminders (event_id, remind_date, times_per_day)
       SELECT id, $2::date, $3 FROM events WHERE id = $1
       RETURNING ${COLUMNS}`,
      [eventId, remindDate, timesPerDay],
    );
    if (!created) throw new HttpError(404, 'Event not found');
    res.status(201).json(created);
  }),
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    await query('DELETE FROM reminders WHERE id = $1', [parseId(req.params.id)]);
    res.sendStatus(204);
  }),
);

module.exports = router;
