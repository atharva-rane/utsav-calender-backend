'use strict';

const { Router } = require('express');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const { signToken, safeEqual } = require('../middleware/auth');
const { HttpError } = require('../utils/errors');

const router = Router();

// Slow down brute-force attempts on the login endpoints.
router.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 50 }));

// Anyone can browse the calendar as a guest ("user" role).
router.post('/guest', (req, res) => {
  res.json({ token: signToken('user') });
});

// Admin sign-in uses the credentials from .env.
router.post('/admin', (req, res, next) => {
  const { email = '', password = '' } = req.body || {};
  const valid = safeEqual(email, config.admin.email) && safeEqual(password, config.admin.password);

  if (!valid) return next(new HttpError(401, 'Wrong email or password'));
  res.json({ token: signToken('admin') });
});

module.exports = router;
