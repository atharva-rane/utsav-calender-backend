'use strict';

const { Router } = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../utils/errors');
const { parseId } = require('../utils/validation');

const router = Router();
router.use(requireAuth());

const EMAIL_PATTERN = /^\S+@\S+\.\S+$/;
const listRecipients = () => query('SELECT id, email FROM recipients ORDER BY id');

router.get(
  '/',
  asyncHandler(async (req, res) => res.json(await listRecipients())),
);

// POST /api/recipients  { emails: ["a@x.com", "b@y.com"] }  - duplicates/invalid emails are ignored
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const emails = [
      ...new Set(
        (req.body.emails || [])
          .map((email) => String(email).trim().toLowerCase())
          .filter((email) => EMAIL_PATTERN.test(email)),
      ),
    ];

    if (emails.length) {
      await query(
        'INSERT INTO recipients (email) SELECT unnest($1::text[]) ON CONFLICT DO NOTHING',
        [emails],
      );
    }
    res.json(await listRecipients());
  }),
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    await query('DELETE FROM recipients WHERE id = $1', [parseId(req.params.id)]);
    res.sendStatus(204);
  }),
);

module.exports = router;
