'use strict';

const { Router } = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { HttpError, asyncHandler } = require('../utils/errors');
const { isIsoDate, parseEventBody, parseId } = require('../utils/validation');

const router = Router();
router.use(requireAuth());

const COLUMNS = `id, title, date, to_char(time, 'HH24:MI') AS time, location, description, source`;

// GET /api/events?from=YYYY-MM-DD&to=YYYY-MM-DD
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const { from = '1900-01-01', to = '2999-12-31' } = req.query;
    if (!isIsoDate(from) || !isIsoDate(to)) {
      throw new HttpError(400, 'from/to must be YYYY-MM-DD dates');
    }
    const rows = await query(
      `SELECT ${COLUMNS} FROM events
       WHERE date BETWEEN $1 AND $2
       ORDER BY date, events.time NULLS FIRST, id`,
      [from, to],
    );
    res.json(rows);
  }),
);

// GET /api/events/search?q=diwali  - title search across all dates (upcoming first, then past)
router.get(
  '/search',
  asyncHandler(async (req, res) => {
    const term = String(req.query.q ?? '')
      .trim()
      .slice(0, 100);
    if (!term) return res.json([]);

    // strpos() avoids LIKE wildcards (%, _) in the search text being interpreted.
    const rows = await query(
      `SELECT ${COLUMNS} FROM events
       WHERE strpos(lower(title), lower($1)) > 0
       ORDER BY (date < CURRENT_DATE),
                CASE WHEN date >= CURRENT_DATE THEN date END ASC,
                CASE WHEN date < CURRENT_DATE THEN date END DESC,
                events.time NULLS FIRST
       LIMIT 100`,
      [term],
    );
    res.json(rows);
  }),
);

router.post(
  '/',
  asyncHandler(async (req, res) => {
    const e = parseEventBody(req.body);
    const [created] = await query(
      `INSERT INTO events (title, date, time, location, description, source)
       VALUES ($1, $2, NULLIF($3, '')::time, $4, $5, 'user')
       RETURNING ${COLUMNS}`,
      [e.title, e.date, e.time, e.location, e.description],
    );
    res.status(201).json(created);
  }),
);

router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    const e = parseEventBody(req.body);
    const [updated] = await query(
      `UPDATE events
       SET title = $1, date = $2, time = NULLIF($3, '')::time, location = $4, description = $5
       WHERE id = $6
       RETURNING ${COLUMNS}`,
      [e.title, e.date, e.time, e.location, e.description, id],
    );
    if (!updated) throw new HttpError(404, 'Event not found');
    res.json(updated);
  }),
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    await query('DELETE FROM events WHERE id = $1', [parseId(req.params.id)]);
    res.sendStatus(204);
  }),
);

module.exports = router;
