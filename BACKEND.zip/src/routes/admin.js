'use strict';

const { Router } = require('express');
const multer = require('multer');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { HttpError, asyncHandler } = require('../utils/errors');
const { parseEventsWorkbook } = require('../services/excelParser');

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// POST /api/admin/upload  (multipart field "file": .xlsx / .xls / .csv)
router.post(
  '/upload',
  requireAuth('admin'),
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!req.file) throw new HttpError(400, 'Choose an Excel file');

    const { rows, skipped } = parseEventsWorkbook(req.file.buffer);
    if (!rows.length) {
      throw new HttpError(
        400,
        'No valid rows found. Use columns: title, date (YYYY-MM-DD), time, description, location',
      );
    }

    // One round-trip: Postgres unpacks the JSON array into rows.
    await query(
      `INSERT INTO events (title, date, time, description, location, source)
       SELECT title, date::date, NULLIF(time, '')::time, description, location, 'admin'
       FROM jsonb_to_recordset($1::jsonb)
         AS x(title text, date text, time text, description text, location text)`,
      [JSON.stringify(rows)],
    );

    res.json({ imported: rows.length, skipped });
  }),
);

module.exports = router;
