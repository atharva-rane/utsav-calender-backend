'use strict';

const pg = require('pg');
const config = require('./config');

// Return DATE columns (type 1082) as plain 'YYYY-MM-DD' strings, avoiding timezone shifts.
pg.types.setTypeParser(1082, (value) => value);

const useSsl = /sslmode=require|neon\.tech/.test(config.databaseUrl);

const pool = new pg.Pool({
  connectionString: config.databaseUrl,
  ssl: useSsl ? { rejectUnauthorized: false } : false,
  max: 10,
});

/** Run a parameterised query and return the rows. */
const query = (sql, params) => pool.query(sql, params).then((result) => result.rows);

/** Create tables on first start (safe to run every time). */
async function initSchema() {
  await query(`
    CREATE TABLE IF NOT EXISTS events (
      id          SERIAL PRIMARY KEY,
      title       TEXT NOT NULL,
      date        DATE NOT NULL,
      time        TIME,
      location    TEXT DEFAULT '',
      description TEXT DEFAULT '',
      source      TEXT DEFAULT 'user',
      created_at  TIMESTAMPTZ DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS events_date_idx ON events(date);

    CREATE TABLE IF NOT EXISTS recipients (
      id    SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reminders (
      id            SERIAL PRIMARY KEY,
      event_id      INT REFERENCES events(id) ON DELETE CASCADE,
      remind_date   DATE NOT NULL,
      times_per_day INT DEFAULT 1,
      sent_count    INT DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS reminders_date_idx ON reminders(remind_date);
  `);
}

module.exports = { query, initSchema };
