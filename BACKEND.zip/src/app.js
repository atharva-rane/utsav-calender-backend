'use strict';

const express = require('express');
const cors = require('cors');
const config = require('./config');
const { errorHandler } = require('./utils/errors');

function createApp() {
  const app = express();

  app.use(cors({ origin: config.corsOrigins.includes('*') ? true : config.corsOrigins }));
  app.use(express.json({ limit: '1mb' }));

  app.use('/api/auth', require('./routes/auth'));
  app.use('/api/events', require('./routes/events'));
  app.use('/api/recipients', require('./routes/recipients'));
  app.use('/api/reminders', require('./routes/reminders'));
  app.use('/api/admin', require('./routes/admin'));

  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
